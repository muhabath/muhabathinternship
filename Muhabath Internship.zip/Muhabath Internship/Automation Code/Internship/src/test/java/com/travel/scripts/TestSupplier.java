package com.travel.scripts;

import java.io.IOException;

import org.testng.annotations.Test;

import com.travel.pages.Supplier;
import com.travel.utilities.Excelutility;

public class TestSupplier extends TestBase{
	
	Supplier objsupp;
	Excelutility objread;
	
@Test(priority=1)
	
	public void verifylogin() throws IOException
	{
	objsupp=new Supplier(driver);
	objread=new Excelutility();
	String StrArray[][] = Excelutility.getCellData();
	objsupp.mail(StrArray[4][0]);
	objsupp.Pass(StrArray[4][1]);
	objsupp.submit();
	
	}
@Test(priority=6)
 public void checkstatement() throws IOException
 {
	
	objsupp.salesandsummary();
 }
	
@Test(priority=7)
public void checkrevenuebreakdown()
{
	objsupp.revenuebreakdown();
}

@Test(priority=8)
 public void pendingbookings()
 
 {
	objsupp.pendingbooking();
	objsupp.statuscha();
	objsupp.confirmed();
	driver.quit();
	
 }
@Test(priority=2)
 public void verifytour()
 {
	
	objsupp.tours();
	
 }
@Test(priority=3)
public void verifyflight()
{
	objsupp.Flight();
}

@Test(priority=4)

public void verifyvisanbook() {
	
	objsupp.Visa();
}

@Test(priority=5)

public void verfybook() {
	

	objsupp.Bookings();
	driver.navigate().back();
 }

}
