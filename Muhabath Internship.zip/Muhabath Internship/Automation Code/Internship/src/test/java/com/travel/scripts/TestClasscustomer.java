package com.travel.scripts;

import java.io.IOException;
import java.time.Duration;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

import com.travel.pages.Customer;
import com.travel.utilities.Excelutility;

public class TestClasscustomer extends TestBase {
	
	Customer objcust;
	Excelutility objread;
	
	
	@Test(priority=1)
	public void VerifyValidLogin() throws IOException
	{
		objcust=new Customer(driver);
		objread=new Excelutility();
		String StrArray[][] = Excelutility.getCellData();
		objcust.mail(StrArray[0][0]);
		objcust.Pass(StrArray[0][1]);
		objcust.submit();
		objcust.logout();
	}
	
	@Test(priority=2)
	
		public void checklinks() throws IOException
		{
		objcust=new Customer(driver);
		objread=new Excelutility();
		String StrArray[][] = Excelutility.getCellData();
		objcust.mail(StrArray[0][0]);
		objcust.Pass(StrArray[0][1]);
		objcust.submit();
		objcust.mybookings();
		objcust.addfunds();
		objcust.myprofile();
		
		
		}
	@Test(priority=3)
	
	public void addingfunds() throws IOException
	{
		
		objcust.addfunds();
		objcust.paywithpal();
	   
	}
	
@Test(priority=4)
	
	public void voucher() throws IOException
	{
		
		objcust.mybookings();
		objcust.voucher();
		objcust.account();
		
		
	
	}
@Test(priority=5)

public void addressupdate() throws IOException
{
	objcust.myprofile();
	objcust.clearadd1();
	objcust.clearadd2();
	objcust.addressupd1();
	objcust.addressupd2(); 
	objcust.update();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
}
@AfterSuite
public void tearDown()

{

	driver.quit();
}


}

