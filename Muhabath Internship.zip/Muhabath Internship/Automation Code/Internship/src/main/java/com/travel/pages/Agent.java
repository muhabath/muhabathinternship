package com.travel.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;



public class Agent {

	WebDriver driver;
	WebDriverWait wait;
	
	@FindBy(css="input[name='email'][type='email']")
	private WebElement emailid;
	@FindBy(css="input[type='password']")
	private WebElement pass;
	@FindBy(xpath="//div[@class='btn-box pt-3 pb-4']/child::button[@type='submit']")
	private WebElement login;
	@FindBy(css="a[class=' waves-effect'][href='https://phptravels.net/account/logout']")
	private WebElement lgout;
	@FindBy(css="a[href='https://phptravels.net/account/bookings'][class=' waves-effect']")
	private WebElement mybook;
	@FindBy(css="a[href='https://phptravels.net/account/add_funds'][class=' waves-effect']")
	private WebElement adfun;
	@FindBy(css="a[href='https://phptravels.net/account/profile'][class=' waves-effect']")
	private WebElement myprof;
	@FindBy(css="a[href='https://phptravels.net/hotels\']")
	private WebElement hot;
	@FindBy(css="a[href='https://phptravels.net/tours']")
	private WebElement trs;
	@FindBy(partialLinkText="Rose")
	private WebElement dis;
	@FindBy(linkText="Transfers")
	private WebElement tran;
	@FindBy(linkText="Visa")
	private WebElement vis;
	@FindBy(linkText="Offers")
	private WebElement off;
	@FindBy(linkText="Blog")
	private WebElement blog;
	@FindBy(linkText="Flights")
	private WebElement flght;
	@FindBy(partialLinkText="Dubai")
	private WebElement dest;
	@FindBy(id="select2-hotels_city-container")
	private WebElement city;
	@FindBy(css="input[class='select2-search__field']")
	private WebElement search;
	@FindBy(xpath="//i[@class='flag dk']")
	private WebElement selcity;
	@FindBy(id="submit")
	private WebElement sub;
    @FindBy(id="currency")
    private WebElement cur;
    @FindBy(xpath="//a[@href='https://phptravels.net/currency-INR']")
    private WebElement inr;
	
	
	
	
	public Agent (WebDriver driver)
	{
		this.driver=driver;
		
		PageFactory.initElements(driver, this);
		this.wait=new WebDriverWait(driver,Duration.ofSeconds(60));
	
	}
	

	public void mail(String strEmailid)
	{
		emailid.sendKeys(strEmailid);
		
	}
	
	public void Pass(String strPass)
	{
	pass.sendKeys(strPass);	
	}
	public void submit() 
	{
		login.click();
		
	}
	
	public void toclear()
	{
		emailid.clear();
		pass.clear();
	}
	public void logout()
	{
		lgout.click();
	}
	
   public void mybookings()
{
	mybook.click();
}
public void addfunds()
{
	adfun.click();
}
public void myprofile() {
	myprof.click();
}

   public void hotels() {
	   hot.click();
   }
   
   public void tours()
   {
	  trs.click(); 
   }
   
   public void discount()
   {
	   Actions actions =new Actions(driver);
		actions.moveToElement(dis);
		actions.perform();
	   dis.click();
   }
   
   public void clicktransfers() 
   {
	   tran.click();
   }
   public void clickvisa()
   {
	   vis.click();
   }
   public void clickoffers()
   {
	   off.click();
   }
   public void reachdestination()
   {
	   dest.click();
   }
   
   
   
   public void tosearchbycity()
   {
	   city.click();
   }
   public void searchcity() {

   search.sendKeys("Aab");
   }
   public void toclickcity()
   {
	   selcity.click();
   }
   public void searchscity() 
   {
	   sub.click();
	   
   }
   public void updcur()
   {
	   cur.click();
   }
   public void currencyup() {
	   inr.click();
   }
   
   public void blogs() {
	   blog.click();
   }
   public void flights() {
	   flght.click();
   }
}
