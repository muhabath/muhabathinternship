package com.travel.scripts;

import java.io.IOException;
import java.time.Duration;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

import com.travel.pages.Agent;
import com.travel.utilities.Excelutility;

public class TestClassAgent extends TestBase{
	
	Agent objagen;
	Excelutility objread;
	
	@Test(priority=1)
	
	public void VerifyValidLogin() throws IOException
	{
		objagen=new Agent(driver);
		objread=new Excelutility();
		String StrArray[][] = Excelutility.getCellData();
		objagen.mail(StrArray[2][0]);
		objagen.Pass(StrArray[2][1]);
		objagen.submit();
		objagen.logout();
		objagen.toclear();
	}
	

	@Test(priority=2)
	
	public void Verifylink() throws IOException
	{
		objagen=new Agent(driver);
		objread=new Excelutility();
		String StrArray[][] = Excelutility.getCellData();
		objagen.mail(StrArray[2][0]);
		objagen.Pass(StrArray[2][1]);
		objagen.submit();
		objagen.mybookings();
		objagen.addfunds();
		objagen.myprofile();
	
	}
	
	@Test(priority=3)
	
	public void verifytabs() throws IOException
	{
		objagen.tours();
		objagen.hotels();
		objagen.clicktransfers();
		objagen.clickvisa();
		objagen.clickoffers();
		objagen.blogs();
		
	}
	
	@Test(priority=4)
	
	public void reachdestinatonpage() 
	{
		objagen.flights();
		objagen.reachdestination();
		
		
		
	}
	
	@Test(priority=5)
	
	public void searchhotels() throws IOException
	{

		objagen.hotels();
		objagen.tosearchbycity();
		objagen.searchcity();
		objagen.toclickcity();
		objagen.searchscity();
		
		
	}
	
	@Test(priority=6)
	
	public void currencyupdate() 
	
	{
		objagen.updcur();
		objagen.currencyup();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
	}
	@AfterSuite
	public void tearDown()

	{

		driver.quit();
	}
}
