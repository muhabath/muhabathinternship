package com.travel.scripts;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

import com.travel.pages.Admin;
import com.travel.utilities.Excelutility;

public class TestClassAdmin extends TestBase{
	
	Admin objadmin;
	Excelutility objread;
	
	
	@Test(priority=1)
	
	public void verifylogin() throws IOException
	{
		objadmin=new Admin(driver);
		objread=new Excelutility();
		String StrArray[][] = Excelutility.getCellData();
		objadmin.mail(StrArray[3][0]);
		objadmin.Pass(StrArray[3][1]);
		objadmin.submit();
		objadmin.clickbooking();
		
	
		
		
	}
	@Test(priority=2)
	
	public void invoicesucess()
	{
		objadmin.paidbookings();
		
		objadmin.paidinv();
	}
	
	@Test(priority=3)
	
	public void cancelcheck() {
		
	
		objadmin.tocancell();
		objadmin.cancelled();
	
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(60));
	   	Alert alert = wait.until(ExpectedConditions.alertIsPresent());
	   	alert.accept();
	}
	   	
	   @Test(priority=4)
	   	
	   	public void verifycases()
	   		
	   	{
		objadmin.pending();
		objadmin.status();
		objadmin.statuschanged();
		objadmin.site();
		driver.switchTo().parentFrame();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(120));}
	@AfterSuite
		public void tearDown()

		{

			driver.quit();
			
		}
		
	   	}
	
		
	


