package com.travel.pages;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Customer {
	
	WebDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js = (JavascriptExecutor)driver;
	
	@FindBy(css="input[name='email'][type='email']")
	private WebElement emailid;
	@FindBy(css="input[type='password']")
	private WebElement pass;
	@FindBy(xpath="//div[@class='btn-box pt-3 pb-4']/child::button[@type='submit']")
	private WebElement login;
	@FindBy(css="a[class=' waves-effect'][href='https://phptravels.net/account/logout']")
	private WebElement lgout;
	@FindBy(css="a[href='https://phptravels.net/account/bookings'][class=' waves-effect']")
	private WebElement mybook;
	@FindBy(css="a[href='https://phptravels.net/account/add_funds'][class=' waves-effect']")
	private WebElement adfun;
	@FindBy(css="a[href='https://phptravels.net/account/profile'][class=' waves-effect']")
	private WebElement myprof;
	@FindBy(id="gateway_paypal")
	private WebElement pal;
	@FindBy(xpath="/html/body/section[1]/div/div[2]/div/div[1]/div/div/div[2]/div/table/tbody/tr[1]/td[4]/div/a")
	private WebElement vouc;
	@FindBy(css="input[name='address1']")
	private WebElement add;
	@FindBy(css="input[name='address2']")
	private WebElement add2;
	@FindBy(xpath="//div[@class='header-right-action pt-1 pe-2']")
	private WebElement acc;
	@FindBy(xpath="/html/body/section[1]/div/div[2]/div/div[1]/div/div/div[2]/form/div[3]/button")
	private WebElement upd;

	public Customer (WebDriver driver)
	{
		this.driver=driver;
		
		PageFactory.initElements(driver, this);
		this.wait=new WebDriverWait(driver,Duration.ofSeconds(60));
	
	}

	public void mail(String strEmailid)
	{
		emailid.sendKeys(strEmailid);
		
	}
	
	public void Pass(String strPass)
	{
	pass.sendKeys(strPass);	
	}
	public void submit() 
	{
		login.click();
		
	}
	
	
	public void logout() {
		lgout.click();
	}
	public void mybookings()
	{
		mybook.click();
	}
	public void addfunds()
	{
		adfun.click();
	}
	public void myprofile() {
		myprof.click();
	}
	public void paywithpal()
	{
pal.click();
}
	
	public void voucher()
	{
		vouc.click();
	}
	
	public void addressupd1() {
		
		add.sendKeys("Abc house,thrissur");
	}
	public void addressupd2()
	{
		add2.sendKeys("Kerala");
	}
	
	public void account() {
		acc.click();
	}
	
	public void update()
	{
		{try {
					
					wait.until(ExpectedConditions.visibilityOf(upd));
			js.executeScript("arguments[0].click();",upd);
					upd.click();
					Thread.sleep(1000);
				}
				catch (Exception e) {
				}
		}
			}
	
	
	public void clearemail()
	{
		emailid.clear();
	}
	public void clearpass()
	{
		pass.clear();
	}
	public void clearadd1()
	{
		add.clear();
	}
	public void clearadd2() {
		
		add2.clear();
	}
}
