package com.travel.pages;

import java.time.Duration;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Supplier {
	
	WebDriver driver;
	WebDriverWait wait;
	

	@FindBy(css="input[name='email'][type='text']")
	private WebElement emailid;
	@FindBy(css="input[type='password']")
	private WebElement pass;
	@FindBy(css="button[type='submit']")
	private WebElement login;
	@FindBy(css="div[class='text-muted']")
	private WebElement sales;
	@FindBy(css="body[class='nav-fixed bg-light']")
	private WebElement rev;
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div[2]/a/div/div/div")
	private WebElement pen;
	@FindBy(css="select[id='booking_status']")
	private WebElement stat;
	@FindBy(css="option[class='Confirmed'][value='64,hotels,Confirmed']")
	private WebElement confirm;
	@FindBy(css="a[aria-controls='toursmodule']")
	private WebElement tour;
	@FindBy(linkText="flights")
	private WebElement flight ;
	@FindBy(linkText="Visas")
	private WebElement visa;
	@FindBy(css="a[href='https://phptravels.net/api/supplier/bookings\']")
	private WebElement book;
	@FindBy(linkText="DASHBOARD")
	private WebElement dash;
	
	
	public Supplier (WebDriver driver)
	{
		this.driver=driver;
		
		PageFactory.initElements(driver, this);
		this.wait=new WebDriverWait(driver,Duration.ofSeconds(60));
	
	}

	public void mail(String strEmailid)
	{
		emailid.sendKeys(strEmailid);
		
	}
	
	public void Pass(String strPass)
	{
	pass.sendKeys(strPass);	
	}
	public void submit() 
	{
		login.click();
		
	}
	public void salesandsummary()
	{
		if(sales.isDisplayed())
		{
		System.out.println("Sales overview & summary");
		}
		 
		else
		{
		System.out.println("Element not found");
		
		}
		
	}
	
	
	
	public void revenuebreakdown() 
	{
		if(rev.isDisplayed())
		{
		System.out.println("Revenue Breakdown");
		}
		 
		else
		{
		System.out.println("Element not found");
		
		}
	}
	
	public void pendingbooking()
	{
		pen.click();
	}
	public void statuscha() {
		stat.click();
	}

	public void confirmed() {
		confirm.click();
	}
	
	
	public void tours()
	{

		if(tour.isDisplayed())
		{
		System.out.println("Tour is present");
		tour.click();
		}
		 
		else
		{
		System.out.println("Element not found");
		
		}
		
	}
	public void Flight()
	{

		if(flight.isDisplayed())
		{
		System.out.println("Flights is present");
		flight.click();
		}
		 
		else
		{
		System.out.println("Flight not found");
		
		}
		
	}
	public void Visa()
	{

		if(visa.isDisplayed())
		{
		System.out.println("Visa is present");
		visa.click();
		}
		 
		else
		{
		System.out.println("Visa not found");
		
		}
		
	}
	public void Bookings()
	{

		if(book.isDisplayed())
		{
		System.out.println("Bookings is present");
		book.click();
		}
		 
		else
		{
		System.out.println("Booking not found");
		
		}
		
	}
	public void dashboard()
	{
		dash.click();
	}
}
