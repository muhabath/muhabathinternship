package com.travel.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Admin {
	
	WebDriver driver;
	WebDriverWait wait;
	
	@FindBy(css="input[name='email'][type='text']")
	private WebElement emailid;
	@FindBy(css="input[type='password']")
	private WebElement pass;
	@FindBy(xpath="//button[@type='submit']")
	private WebElement login;
	@FindBy(xpath="//a[@class='nav-link loadeffect']")
	private WebElement book;
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[1]/div[1]/a/div/div")
	private WebElement success;
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/div/table/tbody/tr[1]/td[14]")
    private WebElement inv;
	@FindBy(xpath="//*[@id=\"layoutDrawer_content\"]/main/div/div[1]/div[3]/a/div/div/div")
	private WebElement can;
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/div/table/tbody/tr/td[15]")
	private WebElement canc;
	@FindBy(css="a[href='https://phptravels.net/api/admin/bookings/pending']")
	private WebElement pen;
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/div/table/tbody/tr[1]/td[11]")
	private WebElement sta;
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/div/table/tbody/tr[1]/td[11]/select/option[2]")
	private WebElement confsta;
	@FindBy(linkText="Website")
	private WebElement web;
	
	
	
	public Admin (WebDriver driver)
	{
		this.driver=driver;
		
		PageFactory.initElements(driver, this);
		this.wait=new WebDriverWait(driver,Duration.ofSeconds(60));
	
	}
	
	public void mail(String strEmailid)
	{
		emailid.sendKeys(strEmailid);
		
	}
	
	public void Pass(String strPass)
	{
	pass.sendKeys(strPass);	
	}
	public void submit() 
	{
		login.click();
		
	}
    public void clickbooking()
    {
    	book.click();
    }
    public void paidbookings()
    {
    	success.click();
    	
    }
    public void paidinv()
    {Actions actions =new Actions(driver);
	actions.moveToElement(inv);
	actions.perform();
           inv.click();
    }
    public void tocancell()
    {
    	can.click();
    }
    public void cancelled()
    {
    	Actions actions =new Actions(driver);
		actions.moveToElement(canc);
		actions.perform();
    	canc.click();
    }
    public void pending()
    {

    	Actions actions =new Actions(driver);
		actions.moveToElement(pen);
		actions.perform();
    	pen.click();
    }
    public void status()
    {
    	Actions actions =new Actions(driver);
		actions.moveToElement(sta);
		actions.perform();
    	sta.click();
    }
    
    public void statuschanged(){
    	confsta.click();
    }
    
    public void site()
    {
    	web.click();
    }
}
